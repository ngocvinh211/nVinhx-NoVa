package com.nvinhx.nova

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 9, 13)
    private val panel = Color.rgb(17, 23, 32)
    private val silver = Color.rgb(220, 230, 244)
    private val muted = Color.rgb(158, 172, 191)
    private val ff = "com.dts.freefireth"
    private val ffMax = "com.dts.freefiremax"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        setContentView(buildUi())
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(bg)
        }
        val brand = TextView(this).apply {
            text = "♛  nVinhx NoVa"
            textSize = 30f
            setTextColor(silver)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "BLACK  /  NEON SILVER  •  GAME LAUNCHER"
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        root.addView(brand, matchWrap())
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(34)))
        val gap = View(this)
        root.addView(gap, LinearLayout.LayoutParams(1, dp(42)))

        root.addView(gameButton("FREE FIRE", "MỞ FREE FIRE", ff), buttonParams())
        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, dp(16)))
        root.addView(gameButton("FREE FIRE MAX", "MỞ FREE FIRE MAX", ffMax), buttonParams())

        val note = TextView(this).apply {
            text = "Chọn game để mở ứng dụng đã cài trên thiết bị.\nNếu chưa cài, NoVa sẽ hướng dẫn bạn đến Google Play."
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, 0)
        }
        root.addView(note, matchWrap())

        val footer = TextView(this).apply {
            text = "ADMIN • Trần Ngọc Vĩnh (nVinhx)"
            textSize = 12f
            setTextColor(silver)
            gravity = Gravity.CENTER
        }
        val footerParams = LinearLayout.LayoutParams(-1, dp(54))
        footerParams.topMargin = dp(24)
        root.addView(footer, footerParams)
        return root
    }

    private fun gameButton(title: String, label: String, packageName: String): Button {
        return Button(this).apply {
            text = "$title\n$label  ›"
            textSize = 16f
            isAllCaps = false
            setTextColor(silver)
            setBackgroundColor(panel)
            setOnClickListener { launchGame(packageName) }
            contentDescription = "Chọn $title để mở game"
        }
    }

    private fun launchGame(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            try {
                startActivity(launchIntent)
            } catch (_: ActivityNotFoundException) {
                showInstallDialog(packageName)
            }
        } else {
            showInstallDialog(packageName)
        }
    }

    private fun showInstallDialog(packageName: String) {
        val gameName = if (packageName == ffMax) "Free Fire MAX" else "Free Fire"
        AlertDialog.Builder(this)
            .setTitle("Chưa tìm thấy $gameName")
            .setMessage("Bạn cần cài đặt game trước khi mở. Đi đến Google Play?")
            .setNegativeButton("ĐỂ SAU", null)
            .setPositiveButton("CÀI ĐẶT NGAY") { _, _ -> openStore(packageName) }
            .show()
    }

    private fun openStore(packageName: String) {
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
        try {
            startActivity(market)
        } catch (_: ActivityNotFoundException) {
            val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName"))
            startActivity(web)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun buttonParams() = LinearLayout.LayoutParams(-1, dp(112))
}
