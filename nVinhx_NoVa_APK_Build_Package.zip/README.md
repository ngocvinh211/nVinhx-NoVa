# nVinhx NoVa — Android + Key Server starter

Admin display name: **Trần Ngọc Vĩnh (nVinhx)**

This is a starter source project, not a compiled APK or a deployed public server. It includes:
- Android native Kotlin launcher UI (black / neon silver) with Free Fire and Free Fire MAX launch buttons.
- NV metallic neon app icon integrated into Android mipmap resources.
- Package visibility declarations for the two game package IDs.
- Node.js + Express key server with admin-authenticated key creation, listing, revocation, and client key validation.
- A minimal dark admin web page.

## Important
- No game memory modification, auto-aim, or game-process injection is included.
- Package IDs commonly used are `com.dts.freefireth` and `com.dts.freefiremax`; verify them for your target region/version.
- Never publish the real admin secret or `.env` file. Use a long random `ADMIN_TOKEN`.
- For production, use HTTPS, a managed database, rate limiting, backups, and proper admin login/MFA. The starter uses a local JSON file for simplicity.
- Android project is source scaffold; open it in Android Studio, sync Gradle, test on device, then build APK.

## Run Key Server
Requires Node.js 20+.
```bash
cd server
cp .env.example .env
# edit .env and set a long random ADMIN_TOKEN
npm install
npm start
```
Server default: `http://localhost:8787`

Open `http://localhost:8787/admin.html` in a browser. Enter the same `ADMIN_TOKEN` in the admin page. Do not expose this HTTP server to the internet; use HTTPS reverse proxy before deployment.

## API
- `POST /api/admin/keys` — create key; header `x-admin-token`
  JSON: `{"label":"customer","durationDays":30}`
- `GET /api/admin/keys` — list keys; header `x-admin-token`
- `POST /api/admin/keys/:id/revoke` — revoke key; header `x-admin-token`
- `POST /api/validate` — validate key
  JSON: `{"key":"NOVA-...","deviceId":"optional-device-id"}`

## Android
Open `android/` in Android Studio. The demo UI launches installed games. Key validation networking is intentionally kept separate from the UI scaffold; connect it to your deployed HTTPS server before distributing a gated version.
